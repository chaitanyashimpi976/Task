package com.assigment.todo_app.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assigment.todo_app.enitity.Project;
import com.assigment.todo_app.enitity.Todo;
import com.assigment.todo_app.repository.ProjectRepository;
import com.assigment.todo_app.repository.TodoRepository;

@Service
public class TodoService {
	
	@Autowired
    private TodoRepository todoRepository;
	
	@Autowired
	private ProjectRepository projectRepository;

    public Todo addTodoToProject(Long projectId, String description) {
        Todo todo = new Todo();
        todo.setDescription(description);
        todo.setCreatedDate(LocalDate.now());
        todo.setStatus(false);
        Project p1 = projectRepository.findById(projectId).orElseThrow();
        todo.setProject(p1);
        return todoRepository.save(todo);
    }

    public List<Todo> getTodosByProject(Long projectId) {
		return null;
        
    }

    public void markTodoAsComplete(Long todoId) {
        Todo todo = todoRepository.findById(todoId).orElseThrow();
        todo.setStatus(true);
        todo.setUpdatedDate(LocalDate.now());
        todoRepository.save(todo);
    }

} 
