package com.assigment.todo_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.assigment.todo_app.enitity.Project;

public interface ProjectRepository extends JpaRepository<Project, Long>{
	

}
