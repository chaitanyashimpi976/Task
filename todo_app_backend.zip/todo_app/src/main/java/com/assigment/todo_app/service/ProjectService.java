package com.assigment.todo_app.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assigment.todo_app.enitity.Project;
import com.assigment.todo_app.repository.ProjectRepository;

@Service
public class ProjectService {
	
	 @Autowired
	    private ProjectRepository projectRepository;

	    public Project createProject(String title) {
	        Project project = new Project();
	        project.setTitle(title);
	        project.setCreatedDate(LocalDate.now());
	        return projectRepository.save(project);
	    }
	    
	    public Project findProjectById(Long id) {
	    	Project project = projectRepository.findById(id).orElseThrow();
	    	return project;
	    }
	    
	    public List<Project> getAllProjects() {
	        return projectRepository.findAll();
	    }

	    public Project updateProjectTitle(Long projectId, String newTitle) {
	        Project project = projectRepository.findById(projectId).orElseThrow();
	        project.setTitle(newTitle);
	        return projectRepository.save(project);
	    }

}
