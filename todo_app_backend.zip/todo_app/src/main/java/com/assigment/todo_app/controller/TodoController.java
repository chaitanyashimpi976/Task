package com.assigment.todo_app.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assigment.todo_app.enitity.Todo;
import com.assigment.todo_app.service.TodoService;

@RestController
@RequestMapping("/api/todos")
@CrossOrigin(origins="http://localhost:5173/")
public class TodoController {
	
	
	 @Autowired
	    private TodoService todoService;

	    @PostMapping("/{projectId}")
	    public ResponseEntity<Todo> addTodo(@PathVariable Long projectId, @RequestBody Map<String, String> request) {
	        Todo todo = todoService.addTodoToProject(projectId, request.get("description"));
	        return new ResponseEntity<>(todo, HttpStatus.CREATED);
	    }

	    @PutMapping("/complete/{todoId}")
	    public ResponseEntity<Void> markAsComplete(@PathVariable Long todoId) {
	        todoService.markTodoAsComplete(todoId);
	        return new ResponseEntity<>(HttpStatus.OK);
	    }

}
