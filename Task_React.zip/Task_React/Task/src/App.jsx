import React from 'react'
import { BrowserRouter,Routes, Route } from 'react-router-dom';
import List from './Components/List';
import Details from './Components/Details';
import Create from './Components/Create';





const App = () => {
  return (
    <BrowserRouter>
      <div className="App">
      <h1>Todo Manager</h1>
      <Routes>
        <Route path="/" element={<List/>} />
        <Route path="/projects/:id" element={<Details/>} />
        <Route path="/create-project" element={<Create />} />
      </Routes>
    </div>
    </BrowserRouter>
  )
}

export default App