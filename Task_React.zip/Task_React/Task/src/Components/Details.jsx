import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const Details = () => {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [newTodo, setNewTodo] = useState('');

  useEffect(() => {
    axios.get(`http://localhost:8080/api/projects/${id}`)
      .then(response => setProject(response.data))
      .catch(error => console.error(error));
  }, [id]);

  const handleAddTodo = () => {
    axios.post(`http://localhost:8080/api/todos/${id}`, { description: newTodo })
      .then(response => {
        setProject(prev => ({
          ...prev,
          todos: [...prev.todos, response.data]
        }));
        setNewTodo('');
      })
      .catch(error => console.error(error));
  };

  const handleCompleteTodo = (todoId) => {
    axios.put(`http://localhost:8080/api/todos/complete/${todoId}`)
      .then(() => {
        setProject(prev => ({
          ...prev,
          todos: prev.todos.map(todo =>
            todo.id === todoId ? { ...todo, status: true } : todo
          )
        }));
      })
      .catch(error => console.error(error));
  };

  if (!project) return <div>Loading...</div>;

  return (
    <div>
      <h2>{project.title}</h2>
      <ul>
        {project.todos?.map(todo => (
          <li key={todo.id}>
            <span>{todo.description}</span>
            <span>{todo.status ? ' (Completed)' : ''}</span>
            {!todo.status && (
              <button onClick={() => handleCompleteTodo(todo.id)}>Mark Complete</button>
            )}
          </li>
        ))}
      </ul>

      <div>
        <input
          type="text"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          placeholder="New Todo"
        />
        <button onClick={handleAddTodo}>Add Todo</button>
      </div>

      <Link to="/">Back to Projects</Link>
    </div>
  );
};

export default Details;